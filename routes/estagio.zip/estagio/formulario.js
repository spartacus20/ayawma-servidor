require('dotenv').config();
const express = require('express')
const { conector } = require('../../mysql_conector.js')
const router = express.Router();


router.post('/api/formulario/add', (req, res) => {

    const { title, date, start_date, finish_date, places_publish, description, images, files} = req.body

    const QUERY = 'INSERT INTO formulario (title, date, start_date, finish_date, places_publish, description, images, files) VALUES (?, ?, ?, ?, ?, ?, ?, ? )';

    conector.query(QUERY, [title, date, start_date, finish_date, places_publish, description, JSON.stringify(images), JSON.stringify(files)], (err) => {
        if (err) console.error(err);
        console.log("Done!");
        res.status(200).send({msg: "Added successfully!"})
    })




})





module.exports = router; 